(function ($, Drupal) {
    'use strict';

    $(document).ready(function() {
        $('#edit-field-designation').on('change', function() {
            var selectedText = $(this).find("option:selected").text();
            if (selectedText == "Director") {
                $( "#edit-field-sub-categories" ).prop( "disabled", true );
                $( "#edit-field-division" ).prop( "disabled", true );
            } else {
                $( "#edit-field-sub-categories" ).prop( "disabled", false );
                $( "#edit-field-division" ).prop( "disabled", false );
            }
        });

        var designation = $('#node-message-edit-form #edit-field-designation').find("option:selected").text();
        if (designation == "Director") {
            $( "#edit-field-sub-categories" ).prop( "disabled", true );
            $( "#edit-field-division" ).prop( "disabled", true );
        } else {
            $( "#edit-field-sub-categories" ).prop( "disabled", false );
            $( "#edit-field-division" ).prop( "disabled", false );
        }
    });

})(jQuery, Drupal);

//window.location.href.indexOf("franky") != -1

