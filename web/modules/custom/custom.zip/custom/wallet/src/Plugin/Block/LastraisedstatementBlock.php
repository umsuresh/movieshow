<?php

namespace Drupal\wallet\Plugin\Block;

use Drupal\user\Entity\User;
use Drupal\Core\Block\BlockBase;

/**
 * Defines a Current statement block block type.
 *
 * @Block(
 *   id = "last_raised_block",
 *   admin_label = @Translation("Last Raised Statement block"),
 *   category = @Translation("Wallet"),
 * )
 */
class LastraisedstatementBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function getCacheMaxAge() {
    return 0;
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $current_user = \Drupal::currentUser();
    $user = User::load($current_user->id());
    $mobileno = '';
    if (isset($user->get('field_phone_number')->value) && !empty($user->get('field_phone_number')->value)) {
      $mobileno = $user->get('field_phone_number')->value;
    }

    $result = ['mobile_no' => $mobileno];
    return [
      '#theme' => 'last_raised_statement',
      '#data' => $result,
    ];
  }

}
