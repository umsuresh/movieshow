
(function ($) {
  var $walletList;

  $walletList = $('div.wallet-list');
  var wallet_bal = drupalSettings.wallet.wallet_bal
  var current_month_cons = drupalSettings.wallet.current_month_cons
  var last_trans_date = drupalSettings.wallet.last_trans_date
  var merchant = drupalSettings.wallet.merchant
  var wallet_status = drupalSettings.wallet.wallet_status

if(wallet_status == "Active"){
  $walletListItem = '<div style="width:50%; float:left" ><div id="wallet-active" style="width:100%; float:left;clear: both;padding-left: 5%;padding-top: 5%;">Active</div><div id="wallet-block-bal"  style=" margin: 10px;width: 100%;clear: both;padding-top: 32px;"><div style=" float: left; padding-right: 5%;font-size: 25px;padding-left: 8%;" >OMR</div><div style="float: left;font-size: 35px;">'+wallet_bal+'</div></div><div id="wallet-block-bal"   style="width: 100%;text-align: center;">Wallet Balance</div></div><div style="width:50%; float:left" ><div class="content" style="padding:10px;text-align: center;"><p style="line-height: .5;">Current Month</p> <p style="line-height: .5;">consumption</p></div><div id="wallet-block-bal"  style=" margin: -5px;width: 100%;text-align: center;clear: both;"><div style=" float: left; padding-right: 5%;font-size: 20px;padding-left: 26%;" >OMR</div><div style="float: left;font-size: 25px;">'+current_month_cons+'</div></div><div class="content" style="padding:1px;text-align: center;clear: both;"><p style="line-height: .5;">Last Transaction</p> <a  alt="'+merchant+'" title="'+merchant+'" class="tooltip_link center" style="line-height: .5;">'+last_trans_date+'</a> </div></div><div id="wallet-block-bal"  style=" margin: 10px;width: 100%;"><div style=" float: left; padding-right: 5%;font-size: 12px;" ><a href="">View Current Statement</a></div><div style="float: left;padding-right: 5%;font-size: 12px;"><a href="">Last raised Statement</a></div><div style="float: left;padding-right: 5%;font-size: 12px;"><a href="">View more</a></div></div>';
  $walletList.append($walletListItem);
}else if(wallet_status == "Hold"){
  $walletListItem = '<div style="width:50%; float:left" ><div id="wallet-active" style="width:100%; float:left;clear: both;padding-left: 5%;padding-top: 5%;">Hold</div><div id="wallet-block-bal"  style=" margin: 10px;width: 100%;clear: both;padding-top: 32px;"><div style=" float: left; padding-right: 5%;font-size: 25px;padding-left: 8%;color:#ccc;" >OMR</div><div style="float: left;font-size: 35px;color:#ccc;">'+wallet_bal+'</div></div><div id="wallet-block-bal"   style="width: 100%;text-align: center;color:#ccc;">Wallet Balance</div></div><div style="width:50%; float:left" ><div class="content" style="padding:10px;text-align: center;"><p style="line-height: .5;color:#ccc;">Current Month</p> <p style="line-height: .5;color:#ccc;">consumption</p> </div><div id="wallet-block-bal"  style=" margin: -5px;width: 100%;text-align: center;clear: both;"><div style=" float: left; padding-right: 5%;font-size: 20px;padding-left: 26%;color:#ccc;" >OMR</div><div style="float: left;font-size: 25px;color:#ccc;">'+current_month_cons+'</div></div><div class="content" style="padding:1px;text-align: center;clear: both;"><p style="line-height: .5;color:#ccc;">Last Transaction</p> <a style="line-height: .5;color:#ccc;" alt="'+merchant+'">'+last_trans_date+'</a> </div>  </div><div id="wallet-block-bal" style=" margin: 10px;width: 100%;"><div style=" float: left; padding-right: 5%;font-size: 12px;" ><a href="" style="color:#ccc;">View Current Statement</a></div><div style="float: left;padding-right: 5%;font-size: 12px;"><a href="" style="color:#ccc;">Last raised Statement</a></div><div style="float: left;padding-right: 5%;font-size: 12px;"><a href="">View more</a></div></div>';
  $walletList.append($walletListItem);
}else{
  $walletListItem = '<div style="width:100%; float:left padding-top:10px;" >Not Active in your Wallet </div>';
  $walletList.append($walletListItem);
}
})(jQuery);