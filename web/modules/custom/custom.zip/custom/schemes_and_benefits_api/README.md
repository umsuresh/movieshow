# Schemes & Benefits API

ABOUT
------------
This module is for using Serialization for API rendering. The module also supports API formatting, Removed tags and URL changes for embedded images and cover image.

PRE-REQUIREMENTS
------------------
This module requires or refers
Module:
 	-> Serialization Module
Specific for Coin Project
