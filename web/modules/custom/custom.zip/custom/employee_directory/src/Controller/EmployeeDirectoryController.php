<?php

namespace Drupal\employee_directory\Controller;

use Drupal\user\Entity\User;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\media\Entity\Media;
use Drupal\Core\File\FileSystemInterface;

/**
 * Employee Profile related functionalities.
 */
class EmployeeDirectoryController extends ControllerBase {

  /**
   * Get the api username .
   */

  protected $api_username;

  /**
   * Get the api password .
   */

  protected $api_password;

  /**
   * Get the api url .
   */

  protected $api_url;

  /**
   * Get the api image url .
   */

  protected $api_imageurl;

  /**
   *
   */
  public function __construct() {
    $configFactory = \Drupal::configFactory();
    $this->api_username = $configFactory->get('API.settings')->get('USERNAME');
    $this->api_password = $configFactory->get('API.settings')->get('PASSWORD');
    $this->api_url = $configFactory->get('API.settings')->get('URL');
    $this->api_imageurl = $configFactory->get('API.settings')->get('IMAGE_URL');
  }

  /**
   * Get employee profile data from API.
   *
   * @param int $emp_id
   *   User employee id.
   *
   * @param int $mobile_no
   *   User phone number.
   *
   * @param string $adid
   *   User ADID.
   */
  public function getApiDataEmpDir($emp_id, $mobile_no, $adid) {
    try {
      $type = '$format=json';
      $url = $this->api_url . "/EmpDirSet(LvEmpid='" . $emp_id . "',LvAdid='" . $adid . "',LvMobNo='" . $mobile_no . "')?" . $type;
      $response = \Drupal::httpClient()
        ->get(
          $url, [
            'auth' => [$this->api_username, $this->api_password],
          ]
        );
      $json_data = $response->getBody()->getContents();
      $result = json_decode($json_data);
      return $result;
    }
    catch (RequestException $e) {
      $message = 'Failed to call the Employee profile api';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Update the Bulk Employee Profile data from API.
   */
  public function getApiBulkDataEmpDir($date, $time) {
    try {
      $filter = '$filter=IV_Empid';
      $type = '$format=json';
      $datetime = $date . "T" . $time;
      $url = $this->api_url . "/EmpDbulkSet?" . $filter . " eq ' ' and IV_Date eq datetime'" . $datetime . "'&" . $type;
      $response = \Drupal::httpClient()
        ->get(
            $url, [
              'auth' => [$this->api_username, $this->api_password],
            ]
        );
      $json_data = $response->getBody()->getContents();
      return json_decode($json_data);
    }
    catch (RequestException $e) {
      $message = 'Failed to call the employee profile bulk data api.';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Update Employee Directory Data.
   */
  public function updateEmployeeDirectoryData($result, $uid) {
    try {
      $user = User::load($uid);
      if ($result->d->EmpId != '') {
        $user->set('field_employee_id', $result->d->EmpId);
      }
      if ($result->d->Adid != '') {
        $user->set('field_adid', $result->d->Adid);
      }
      if ($result->d->Email != '') {
        $user->set('mail', $result->d->Email);
      }
      if ($result->d->FirstName != '') {
        $user->set('field_first_name', $result->d->FirstName);
      }
      if ($result->d->MiddleName != '') {
        $user->set('field_middle_name', $result->d->MiddleName);
      }
      if ($result->d->LastName != '') {
        $user->set('field_last_name', $result->d->LastName);
      }
      if ($result->d->LocationCode != '') {
        $user->set('field_location_code', $result->d->LocationCode);
      }
      if ($result->d->LocationText != '') {
        $user->set('field_location_text', $result->d->LocationText);
      }
      if ($result->d->Doj != '') {
        $doj = $this->convertSapDate($result->d->Doj);
        $user->set('field_doj', $doj);
      }
      if ($result->d->Dob != '') {
        $dob = $this->convertSapDate($result->d->Dob);
        $user->set('field_dob', $dob);
      }
      if ($result->d->UserStatus != '') {
        if ($result->d->UserStatus == '3') {
          $field_user_status = 'Active';
        }
        elseif ($result->d->UserStatus == '1') {
          $field_user_status = 'Inactive';
        }
        else {
          $field_user_status = 'Withdrawn';
        }
        $user->set('field_user_status', $field_user_status);
      }
      if ($result->d->CPhoneNo != '') {
        $user->set('field_phone_number', $result->d->CPhoneNo);
      }
      if ($result->d->PayrollArea != '') {
        $user->set('field_payroll_area', $result->d->PayrollArea);
      }
      if ($result->d->Nationality != '') {
        $user->set('field_nationality', $result->d->Nationality);
      }
      if ($result->d->CompanyCode != '') {
        $user->set('field_company_code', $result->d->CompanyCode);
      }
      if ($result->d->WalletLimit != '') {
        $user->set('field_wallet_limit', $result->d->WalletLimit);
      }
      if ($result->d->Cluster != '') {
        $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => $result->d->Cluster, 'vid' => 'sap_cluster']);
        $term = reset($term);
        $cluster_id = $term->get('field_cluster')->target_id;
        $user->set('field_cluster', $cluster_id);
      }
      if ($result->d->Division != '') {
        $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => $result->d->Division, 'vid' => 'sap_division']);
        if (count($term) > 0) {
          $term = reset($term);
          $division_id = $term->get('field_division')->target_id;
          $user->set('field_division', $division_id);
        }
      }
      $user->save();
      return TRUE;
    }
    catch (RequestException $e) {
      $message = 'Failed to update the employee profile data.';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Update Bulk Employee Data.
   */
  public function updateBulkEmployeeDirectoryData($result) {
    try {
      $userStorage = \Drupal::entityTypeManager()->getStorage('user');
      $query = $userStorage->getQuery();
      $uid = $query
        ->condition('field_employee_id', $result->Empid)
        ->execute();
      if (!empty($uid)) {
        $user = User::load($uid);
        if ($result->Userstatus != "") {
          if ($result->UserStatus == '3') {
            $field_user_status = 'Active';
          }
          elseif ($result->UserStatus == '1') {
            $field_user_status = 'Inactive';
          }
          else {
            $field_user_status = 'Withdrawn';
          }
          $user->set('field_user_status', $field_user_status);
        }
        if ($result->PArea != "") {
          $user->set('field_company_code', $result->PArea);
        }
        if ($result->Plans != "") {
          $user->set('field_plans', $result->Plans);
        }
        if ($result->Division != "") {
          $user->set('field_division', $result->Division);
        }
        if ($result->RManager != "") {
          $user->set('field_response_manager', $result->RManager);
        }
        if ($result->CPhone != "") {
          $user->set('field_phone_number', $result->CPhone);
        }
        if ($result->Division != '') {
          $term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadByProperties(['name' => $result->Division, 'vid' => 'sap_division']);
          $term = reset($term);
          $division_id = $term->get('field_division')->target_id;
          $user->set('field_division', $division_id);
        }
        $user->save();
        return TRUE;
      }
    }
    catch (RequestException $e) {
      $message = 'Failed to bulk update the Employee directory data';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Get Api Data Employee Structure Update.
   */
  public function getApiDataEmpStr($emp_id) {
    try {
      $filter = '$filter=IvempId';
      $type = '$format=json';
      $url = $this->api_url . "/EmpStrucSet?" . $filter . " eq '" . $emp_id . "'and IvAdid eq ' '&" . $type;
      \Drupal::logger('API URL')->error($url);
      $response = \Drupal::httpClient()
        ->get(
            $url, [
              'auth' => [$this->api_username, $this->api_password],
            ]
        );
      $json_data = $response->getBody()->getContents();
      return json_decode($json_data);
    }
    catch (RequestException $e) {
      $message = 'Failed to call the Employee Structure api';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Get Api Bulk Data Employee Directory Update.
   */
  public function getApiBulkDataEmpStr($date, $time) {
    try {
      $filter = '$filter=IV_Empid';
      $type = '$format=json';
      $datetime = $date . "T" . $time;
      $url = $this->api_url . "/EmpSbulkSet?" . $filter . " eq ' ' and IV_Date eq datetime'" . $datetime . "'&" . $type;
      $response = \Drupal::httpClient()
        ->get(
            $url, [
              'auth' => [$this->api_username, $this->api_password],
            ]
        );
      $json_data = $response->getBody()->getContents();
      return json_decode($json_data);
    }
    catch (RequestException $e) {
      $message = 'Failed to call the Employee Structure bulk data api.';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Update Employee Structure Data.
   */
  public function updateEmployeeStructureData($result, $uid) {
    try {
      $direct_reports = [];
      $report_line = [];

      foreach ($result as $res) {
        $get_image_result = "";
        $getprofile_image_id = "";
        $data = \Drupal::entityTypeManager()->getStorage('paragraph');
        if ($res->Ind == "") {
          $field_type = "reporting_line";
          $field_cond = "field_id";
        }
        if ($res->Ind != "") {
          $field_type = "direct_reports";
          $field_cond = "field_dr_id";
        }
        /* Select the field details from paragraph table */
        $paragraph_ids = $data->loadByProperties(['parent_id' => $uid, 'type' => $field_type, $field_cond => $res->MEmpid]);
        $paragraph_value = array_keys($paragraph_ids);
        $paragraph_count = count($paragraph_value);

        /*Get the image for reporting user and Direct user profile and stored * */
        try {

          $get_image_result = $this->getApiEmpProfile($res->MEmpid);
          if (isset($get_image_result['response']) && $get_image_result['response']->getStatusCode() == 200) {
            $getprofile_image_id = $this->profie_media_generate($get_image_result, $res->MEmpid);
            \Drupal::logger('Paragraph')->info(" profie_media_generate image_id" . $getprofile_image_id[0]);
          }
        }
        catch (\Ecxeption $e) {
          $get_image_result = "";
          $getprofile_image_id = "";
          $message = 'Reporting Line,Direct Reports user Image not updated to Fields';
          \Drupal::logger('Paragraph')->error($e);
        }
        /*Get the image for reporting user and Direct user profile and stored * */

        if ($paragraph_count > 0) {
          for ($i = 0; $i < $paragraph_count; $i++) {
            /* Load the paragraph field */
            $paragraph = Paragraph::load($paragraph_value[$i]);
            if ($i == 0) {
              /* Update the reporting line field details */
              if ($res->Ind == "") {
                $paragraph->set('field_name', $res->MEname);
                if (!empty($getprofile_image_id[0])) {
                  $message = 'Reporting ,Direct Reports Image ID' . $getprofile_image_id[0];
                  \Drupal::logger('Paragraph')->error($message);
                  $paragraph->set('field_reporting_profile_image', $getprofile_image_id[0]);
                }
                $paragraph->save();
                $report_line[] = [
                  'target_id' => $paragraph->id(),
                  'target_revision_id' => $paragraph->getRevisionId(),
                ];
              }
              /* Update the direct reports field details */
              if ($res->Ind != "") {
                $paragraph->set('field_dr_name', $res->MEname);
                if (!empty($getprofile_image_id[0])) {
                  $message = 'Reporting ,Direct Reports Image ID' . $getprofile_image_id[0];
                  \Drupal::logger('Paragraph')->error($message);
                  $paragraph->set('field_director_profile_image', $getprofile_image_id[0]);
                }
                $paragraph->save();
                $direct_reports[] = [
                  'target_id' => $paragraph->id(),
                  'target_revision_id' => $paragraph->getRevisionId(),
                ];
              }
            }
            else {
              $paragraph->set('status', 0);
              $paragraph->save();
            }
          }
        }
        else {
          if ($res->Ind == "") {
            if (!empty($getprofile_image_id[0]) && is_numeric($getprofile_image_id[0])) {
              $paragraph = Paragraph::create(
                  [
                    'type' => 'reporting_line',
                    'field_id' => $res->MEmpid,
                    'field_name' => $res->MEname,
                    'field_reporting_profile_image' => $getprofile_image_id[0],
                  ]
              );
            }
            else {
              $paragraph = Paragraph::create(
                [
                  'type' => 'reporting_line',
                  'field_id' => $res->MEmpid,
                  'field_name' => $res->MEname,
                ]
                          );
            }

            $paragraph->save();
            $report_line[] = [
              'target_id' => $paragraph->id(),
              'target_revision_id' => $paragraph->getRevisionId(),
            ];
          }
          if ($res->Ind != "") {
            if (!empty($getprofile_image_id[0]) && is_numeric($getprofile_image_id[0])) {
              $paragraph = Paragraph::create(
                  [
                    'type' => 'direct_reports',
                    'field_dr_id' => $res->MEmpid,
                    'field_dr_name' => $res->MEname,
                    'field_director_profile_image' => $getprofile_image_id[0],
                  ]
              );
            }
            else {
              $paragraph = Paragraph::create(
                [
                  'type' => 'direct_reports',
                  'field_dr_id' => $res->MEmpid,
                  'field_dr_name' => $res->MEname,
                ]
                          );

            }

            $paragraph->save();
            $direct_reports[] = [
              'target_id' => $paragraph->id(),
              'target_revision_id' => $paragraph->getRevisionId(),
            ];
          }
        }
      }
      $current_user = User::load($uid);
      $current_user->field_direct_reports = $direct_reports;
      $current_user->field_reporting_line = $report_line;
      $current_user->save();
      return TRUE;
    }
    catch (RequestException $e) {
      $message = 'Failed to update the Reporting Line and Direct Reports Fields';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Update Bulk Employee Structure Data.
   */
  public function updateBulkEmployeeStructureData($result) {
    try {
      $userStorage = \Drupal::entityTypeManager()->getStorage('user');
      $query = $userStorage->getQuery();
      $uid = $query
        ->condition('field_employee_id', $result->Empid)
        ->execute();
      if (!empty($uid)) {
        foreach ($result as $res) {
          /* Employee Reporting Line */
          if ($res->Ind == "") {
            $data = \Drupal::entityTypeManager()->getStorage('paragraph');
            $query = $data->getQuery();
            $pid = $query
              ->condition('parent_id', $uid)
              ->condition('type', 'reporting_line')
              ->condition('field_id', $res->MEmpid, '=')
              ->execute();
            if (!empty($pid)) {
              $update = Database::getConnection()->update('paragraph__field_name');
              $update->fields(['field_name_value' => $res->MEname]);
              $update->condition('revision_id', $pid, '=');
              $update->execute();
            }
            else {
              $paragraph = Paragraph::create(
                    [
                      'type' => 'reporting_line',
                      'parent_id' => $uid,
                      'field_id' => $res->MEmpid,
                      'field_name' => $res->MEname,
                      'parent_field_name' => 'field_reporting_line',
                      'parent_type' => 'user',
                      'status' => 1,
                    ]
                            );
              $paragraph->save();
            }
          }
          /* Employee Direct Reports */
          if ($res->Ind != "") {
            $data = \Drupal::entityTypeManager()->getStorage('paragraph');
            $query = $data->getQuery();
            $drpid = $query
              ->condition('parent_id', $uid)
              ->condition('type', 'direct_reports')
              ->condition('field_dr_id', $res->MEmpid, '=')
              ->execute();
            if (!empty($drpid)) {
              $update = Database::getConnection()->update('paragraph__field_dr_name');
              $update->fields(['field_dr_name_value' => $res->MEname]);
              $update->condition('revision_id', $drpid, '=');
              $update->execute();
            }
            else {
              $paragraph = Paragraph::create(
                        [
                          'type' => 'direct_reports',
                          'parent_id' => $uid,
                          'parent_field_name' => 'field_direct_reports',
                          'parent_type' => 'user',
                          'field_dr_id' => $res->MEmpid,
                          'field_dr_name' => $res->MEname,
                          'status' => 1,
                        ]
                                );
              $paragraph->save();
            }
          }
        }
      }
    }
    catch (RequestException $e) {
      $message = 'Failed to update the bulk data for Reporting Line and Direct Reports Fields';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Adding the Employee directory API response details into database.
   */
  public function addedSapApiResponse($result, $uid) {
    try {
      $current_time = \Drupal::time()
        ->getCurrentTime();
      $res = $result->d;
      $uri = $res->__metadata->uri;
      $cdate = date('Y-m-d H:i:s', $current_time);
      $database = \Drupal::database();
      $database->insert('employee_directory_api_data_updated')->fields(
            [
              'uid' => $uid,
              'api_url' => $uri,
              'api_response' => json_encode($res),
              'updated_date' => $cdate,
            ]
        )->execute();
    }
    catch (RequestException $e) {
      $message = 'Failed to adding the employee directory API response into database';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Adding the Employee structure API response details into database.
   */
  public function addedSapApiEmpStrResponse($result, $uid, $uri) {
    try {
      $current_time = \Drupal::time()
        ->getCurrentTime();
      $cdate = date('Y-m-d H:i:s', $current_time);
      $database = \Drupal::database();
      $database->insert('employee_structure_api_data_updated')->fields(
            [
              'uid' => $uid,
              'api_url' => $uri,
              'api_response' => json_encode($result),
              'updated_date' => $cdate,
            ]
        )->execute();
    }
    catch (RequestException $e) {
      $message = 'Failed to adding the employee structure API response into database';
      \Drupal::logger('employee_directory')->error($message);
      return FALSE;
    }
  }

  /**
   * Converting the date time format into date format.
   */
  public function convertSapDate($str) {
    $match = preg_match('/\/Date\((\d+)\)\//', $str, $date);
    $timestamp = $date[1] / 1000;
    $datetime = new DrupalDateTime();
    $datetime->setTimestamp($timestamp);
    return $datetime->format('Y-m-d');
  }

  /**
   * Get employee profile image from API.
   *
   * @param int $employee_id
   *   User employee id.
   *
   * @return array
   *   The output of user profile, or Null if it was empty.
   */
  public function getApiEmpProfile($employee_id) {
    try {
      $image = '$value';
      $profile_img_url = $this->api_imageurl . "/EmployeePhotoSet('" . $employee_id . "')/$image";
      $response = \Drupal::httpClient()
        ->get(
            $profile_img_url, [
              'auth' => [$this->api_username, $this->api_password],
            ]
        );
      if ($response->getStatusCode() == 200) {
        return ['response' => $response, 'uri' => $profile_img_url];
      }
    }
    catch (\Exception $e) {
      \Drupal::logger('employee_directory')->error("Profile API not called");
      return FALSE;
    }
  }

  /**
   * Get the image API and covert the image into local folder and assign to user profile image.
   *
   * @param array $result
   *   User profile image.
   *
   * @param int $employee_id
   *   User employee id.
   *
   * @return array
   *
   *   The output of user profile, or Null if it was empty.
   */
  public function getProfileImage($result, $employee_id) {
    try {
      if ($result['response']->getStatusCode() == 200) {
        /**Get the Entity  image id  */
        $image_convert_data = $this->api_convert_profile_image($result, $employee_id);
        $message = 'Profile image_converted - ' . $image_convert_data[0];
        \Drupal::logger('employee_directory')->error($message);
        // Profile image save to login user.
        // User details.
        $user = $image_convert_data[2];
        // Image id.
        $user->set('user_picture', $image_convert_data[4]);
        $user->save();
        if ($user->save()) {
          $this->image_response_log($image_convert_data[1], $result, $image_convert_data[3], $employee_id);
        }
      }
      else {
        $message = 'Profile image is not updated - ' . $employee_id;
        \Drupal::logger('employee_directory')->error($message);
      }
    }
    catch (RequestException $e) {
      \Drupal::logger('employee_directory')->error($e->getMessage());
      return FALSE;
    }
  }

  /**
   * Get the image API and covert the image into local folder and assign to user profile image.
   *
   * @param array $result
   *   User profile image.
   * @param int $employee_id
   *   User employee id.
   *
   * @return array
   *   The output of user profile, or Null if it was empty.
   */
  public function profie_media_generate($result, $employee_id) {
    try {
      if ($result['response']->getStatusCode() == 200) {
        /**Get the Entity  image id  */
        $image_convert_data = $this->api_convert_profile_image($result, $employee_id);

        /*Log  for profile image API response*/
        if ($image_convert_data) {
          $log_insert = $this->image_response_log($image_convert_data[1], $result, $image_convert_data[3], $employee_id);
        }
        return $image_convert_data;
      }
      else {
        $message = 'Profile image for Report and Direct updated - ' . $employee_id;
        \Drupal::logger('employee_directory')->error($message);
      }
    }
    catch (RequestException $e) {
      \Drupal::logger('employee_directory')->error($e->getMessage());
      return FALSE;
    }

  }

  /**
   * Get the image API and covert the image into local folder and assign to user profile image.
   *
   * @param array $result
   *   User profile image.
   * @param int $employee_id
   *   User employee id.
   *
   * @return array
   *   The output of user profile, or Null if it was empty.
   */
  public function api_convert_profile_image($result, $employee_id) {

    $json_data = $result['response']->getBody()->getContents();
    $user_id = \Drupal::currentUser()->id();
    $get_user = User::load($user_id);
    $imagebase64 = base64_decode(base64_encode($json_data));
    $image_name  = $employee_id . '_' . uniqid();
    // File Directory creation in "Private.
    $file_repository = \Drupal::service('file.repository');
    $image = $file_repository->writeData(
        $imagebase64, 'private://profile_image/' . $image_name . '.png',
              FileSystemInterface::EXISTS_REPLACE
          );
    // Create media entity saved file.
    $image_media = Media::create(
              [
                'name' => $image_name,
                'bundle' => 'image',
                'uid' => $user_id,
                'langcode' => 'en',
                'status' => 1,
                'field_media_image' => [
                  'target_id' => $image->id(),
                  'alt' => $this->t('Profile image'),
                  'title' => $this->t('Profile image'),
                ],
                "thumbnail" => [
                  "target_id" => $image->id(),
                  "alt" => $this->t('Profile image'),
                ],
                'field_author' => $get_user->name->value,
                'field_date' => \Drupal::time()->getCurrentTime(),
              ]
          );
    $image_media->save();
    $result = [$image_media->id(), $user_id, $get_user, $imagebase64, $image->id()];
    return $result;

  }

  /**
   * Get the image API and covert the image into local folder and assign to user profile image.
   *
   * @param array $result
   *   User profile image.
   * @param int $user_id
   *   User user id.
   * @param string $imagebase64
   *   Image value in imagebase64 format converted .
   * @param string $employee_id
   *   User employee id.
   */
  public function image_response_log($user_id, $result, $imagebase64, $employee_id) {
    /*
    Adding the Employee profile image API response stored into database Log.
     */
    $current_time = \Drupal::time()->getCurrentTime();
    $cdate = date('Y-m-d H:i:s', $current_time);
    $database = \Drupal::database();
    $database->insert('employee_structure_api_data_updated')->fields(
          [
            'uid' => $user_id,
            'api_url' => $result['uri'],
            'profile_image_response' => $imagebase64,
            'updated_date' => $cdate,
          ]
          )->execute();
    $message = 'Profile image updated - ' . $employee_id;
    \Drupal::logger('employee_directory')->info($message);
  }

}
